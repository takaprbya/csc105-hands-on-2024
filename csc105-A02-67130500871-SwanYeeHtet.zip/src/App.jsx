import React, { useState } from 'react';
import './App.css';

function App() {
    const [items, setItems] = useState([]);
    const [newItem, setNewItem] = useState('');
    const [editingId, setEditingId] = useState(null);
    const [editedText, setEditedText] = useState('');

    const addItem = () => {
        if (newItem.trim() !== '') {
            setItems([...items, { id: Date.now(), name: newItem, bought: false }]);
            setNewItem('');
        }
    };

    const toggleBought = (id) => {
        setItems(items.map(item =>
            item.id === id ? { ...item, bought: !item.bought } : item
        ));
    };

    const removeItem = (id) => {
        setItems(items.filter(item => item.id !== id));
    };

    const startEditing = (id, name) => {
        setEditingId(id);
        setEditedText(name);
    };

    const finishEditing = (id) => {
        setItems(items.map(item =>
            item.id === id ? { ...item, name: editedText } : item
        ));
        setEditingId(null);
        setEditedText('');
    };

    return (
        <div className="app-container">
            <h1>Shopping List</h1>
            <div className="input-area">
                <input
                    type="text"
                    placeholder="Add item..."
                    value={newItem}
                    onChange={e => setNewItem(e.target.value)}
                />
                <button onClick={addItem} className="add-button">Add</button>
            </div>
            {items.length > 0 && (
                <ul className="item-list">
                    {items.map(item => (
                        <li key={item.id} className={`item ${item.bought ? 'bought' : ''}`}>
                            {editingId === item.id ? (
                                <div className="edit-item-area">
                                    <input
                                        type="text"
                                        value={editedText}
                                        onChange={(e) => setEditedText(e.target.value)}
                                    />
                                    <button onClick={() => finishEditing(item.id)} className="save-button">Save</button>
                                </div>
                            ) : (
                                <span className="item-name">
                                    {item.name}
                                </span>
                            )}

                            {editingId !== item.id && (
                                <>
                                    <button onClick={() => startEditing(item.id, item.name)} className="edit-button">Edit</button>
                                    <button onClick={() => toggleBought(item.id)} className="crossout-button">
                                        {item.bought ? 'Uncross' : 'Cross Out'}
                                    </button>
                                    <button onClick={() => removeItem(item.id)} className="remove-button">
                                        Remove
                                    </button>
                                </>
                            )}
                        </li>
                    ))}
                </ul>
            )}
            {items.length === 0 && (
                <p>Your shopping list is empty.</p>
            )}
        </div>
    );
}

export default App;
