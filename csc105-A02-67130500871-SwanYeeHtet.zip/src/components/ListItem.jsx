import React, { useState, useRef, useEffect } from 'react';

function ListItem({ item, removeItem, editItem, updateItem }) {
  const [text, setText] = useState(item.text);
  const [isPurchased, setIsPurchased] = useState(item.isPurchased || false); // Add isPurchased state
  const inputRef = useRef(null);

  useEffect(() => {
    if (item.isEditing && inputRef.current) {
      inputRef.current.focus();
    }
  }, [item.isEditing]);

  const handleSave = () => {
    updateItem(item.id, text);
  };

  const handlePurchased = () => {
    setIsPurchased(!isPurchased);
  };

  return (
    <li className={`list-item ${item.isEditing ? 'editing' : ''} ${isPurchased ? 'purchased' : ''}`}>
      {item.isEditing ? (
        <>
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onBlur={handleSave}
            ref={inputRef}
          />
          <button onClick={handleSave}>Save</button>
        </>
      ) : (
        <>
          <span style={{ textDecoration: isPurchased ? 'line-through' : 'none' }}>{item.text}</span>
          <button className="purchased-button" onClick={handlePurchased}>
            Purchased
          </button>
          <button className="edit-button" onClick={() => editItem(item.id)}>Edit</button>
          <button className="remove-button" onClick={() => removeItem(item.id)}>
            Remove
          </button>
        </>
      )}
    </li>
  );
}

export default ListItem;
