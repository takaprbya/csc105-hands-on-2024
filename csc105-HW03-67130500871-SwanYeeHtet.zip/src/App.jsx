import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import AboutMe from "./pages/AboutMe"; 
import GalleryPage from "./pages/GalleryPage";

function App() {
  return (
    <Router>
      <Routes>
        {/* Home Page Route */}
        <Route path="/" element={<Home />} />
        
        {/* About Me Page Route */}
        <Route path="/about" element={<AboutMe />} />

        <Route path="/gallery" element={<GalleryPage />} />
        
      </Routes>
    </Router>
  );
}

export default App;
