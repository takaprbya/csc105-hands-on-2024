import React from 'react'
import AbtMe  from '../components/AbtMe'    

const AboutMe = () => {
  return (
    <div><AbtMe /></div>
  )
}

export default AboutMe