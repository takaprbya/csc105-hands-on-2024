import React from 'react';

const GalleryPage = () => {
  // Sample placeholder images - replace with your actual images
  const placeholderImages = [
    'src/images/image1.jpg',
    'src/images/image2.jpg',
    'src/images/image3.jpg',
    'src/images/image4.jpg',
    'src/images/image5.jpg',
    'src/images/image6.jpg',
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-8">Gallery</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {placeholderImages.map((src, index) => (
          <div key={index} className="border rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow">
            <img 
              src={src} 
              alt={`Gallery image ${index + 1}`}
              className="w-full h-64 object-cover"
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = 'https://via.placeholder.com/400x300?text=Image';
              }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default GalleryPage;
