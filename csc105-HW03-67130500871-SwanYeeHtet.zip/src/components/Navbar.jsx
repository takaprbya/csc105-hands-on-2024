import React, { useState } from "react";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-gray-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo/Name */}
          <div className="text-lg font-bold">SkibidiTaka</div>

          {/* Navigation Links */}
          <div className="hidden md:flex space-x-4">
            <a href="" className="hover:text-gray-300">Home</a>
            <a href="about" className="hover:text-gray-300">About Me</a>
            <a href="gallery" className="hover:text-gray-300">Gallery</a>
          </div>

          {/* Contact Button */}
          <div className="hidden md:block">
            <button className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded">
              Contact
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="focus:outline-none"
            >
              <svg
                className="h-6 w-6"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                {isOpen ? (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  />
                ) : (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-gray-700">
          <a href="#" className="block px-4 py-2 hover:bg-gray-600">
            Home
          </a>
          <a href="#about" className="block px-4 py-2 hover:bg-gray-600">
            About Me
          </a>
          <a href="#gallery" className="block px-4 py-2 hover:bg-gray-600">
            Gallery
          </a>
          <button className="block w-full text-left px-4 py-2 hover:bg-gray-600">
            Contact
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
