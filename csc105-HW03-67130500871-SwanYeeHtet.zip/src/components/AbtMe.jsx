import React from "react";
import aboutPhoto from "../images/aboutme.jpg"; 

const AbtMe = () => {
  return (
    <section className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-6 lg:flex lg:items-center lg:justify-between">
        {/* Photo on the left */}
        <div className="lg:w-1/2 flex justify-center mb-8 lg:mb-0">
          <img
            src={aboutPhoto}
            alt="About Me"
            className="rounded-lg shadow-lg w-2/3 lg:w-full"
          />
        </div>

        {/* Text Content */}
        <div className="lg:w-1/2 space-y-8 lg:ml-12">
          {/* Heading */}
          <h1 className="center text-4xl font-bold text-gray-800">About Me</h1>

          {/* Subheading */}
          <h2 className="text-2xl font-bold text-blue-600">I do stuff yea...</h2>

          {/* Bio/Placeholder Text */}
          <p className="text-gray-600 leading-relaxed font-bold">
            I be waking up, going to classes, coding ,eating, gaming, sleeping. Such is life. Don't click the read more button
          </p>

          {/* Read More Button */}
          <a
            href="https://youtu.be/xvFZjo5PgG0?si=g11vD1JP2UeFqJKg"
            className="inline-block bg-blue-600 text-white font-bold px-6 py-3 rounded-lg border-2 border-blue-700 hover:bg-blue-700"
          >
            Read More
          </a>
        </div>
      </div>
    </section>
  );
};

export default AbtMe;
