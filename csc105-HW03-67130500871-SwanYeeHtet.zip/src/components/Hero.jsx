import React from "react";
import me from "../images/bogosbinted.jpg";

const Hero = () => {
  return (
    <section className="bg-gray-100 py-16">
      <div className="max-w-7xl mx-auto px-6 lg:flex lg:items-center lg:justify-between">
        {/* Text Content */}
        <div className="lg:w-1/2 space-y-8">
          {/* Large Heading */}
          <h1 className="text-5xl font-bold text-gray-800">
            Swan Yee Htet
          </h1>

          {/* Subheading */}
          <h2 className="text-2xl text-blue-600 font-bold">
            Noob Frontend Developer and Professional Backend Developer
          </h2>

          {/* Introduction Text */}
          <p className="mt-4 text-gray-600 leading-relaxed font-bold">
            Some skibidi texts bogos binted! Some skibidi texts bogos binted! Some skibidi texts bogos binted! Some skibidi texts bogos binted! Some skibidi texts bogos binted!
          </p>

          {/* Social Media Icons */}
          <div className="flex justify-center mt-6">
  <div className="flex space-x-6">
    <a
      href="https://youtu.be/xvFZjo5PgG0?si=g11vD1JP2UeFqJKg"
      target="_blank"
      rel="noopener noreferrer"
      className="text-gray-800 hover:text-blue-600 flex items-center space-x-2"
    >
      <i className="fab fa-facebook-f"></i>
      <span className="font-bold">Facebook</span>
    </a>
    <a
      href="https://youtu.be/xvFZjo5PgG0?si=g11vD1JP2UeFqJKg"
      target="_blank"
      rel="noopener noreferrer"
      className="text-gray-800 hover:text-pink-500 flex items-center space-x-2"
    >
      <i className="fab fa-instagram"></i>
      <span className="font-bold">Instagram</span>
    </a>
    <a
      href="https://youtu.be/xvFZjo5PgG0?si=g11vD1JP2UeFqJKg"
      className="text-gray-800 hover:text-red-600 flex items-center space-x-2"
    >
      <i className="far fa-envelope"></i>
      <span className="font-bold">Email</span>
    </a>
  </div>
</div>


          {/* My Portfolio Button */}
          <div className="flex justify-center mt-8">
  <a
    href="#portfolio"
    className="inline-block bg-blue-600 text-white px-6 py-3 font-bold rounded-lg border-2 border-blue-700 hover:bg-blue-700"
  >
    My Portfolio
  </a>
</div>
        </div>

        {/* Professional Photo */}
        <div className="lg:w-1/2 flex justify-center mt-12 lg:mt-0">
          <img
            src={me}
            alt="Professional"
            className="rounded-lg shadow-lg w-2/3 lg:w-full"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;
