import React, { useState } from 'react';
import './App.css';

function SimpleCalculator() {
  const [result, setResult] = useState(0);
  const [input, setInput] = useState('');

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const calculate = (operation) => {
    const inputNumber = parseFloat(input);
    if (isNaN(inputNumber)) return;

    switch (operation) {
      case 'add':
        setResult(result + inputNumber);
        break;
      case 'subtract':
        setResult(result - inputNumber);
        break;
      case 'multiply':
        setResult(result * inputNumber);
        break;
      case 'divide':
        if (inputNumber !== 0) {
          setResult(result / inputNumber);
        } else {
          alert('Cannot divide by zero');
        }
        break;
      default:
        break;
    }
    setInput('');
  };

  const resetInput = () => {
    setInput('');
  };

  const resetResult = () => {
    setResult(0);
  };

  return (
    
    <div className="simple-calculator">
      <h2>Simple Calculator</h2>
      <p>Result: {result}</p>
      <input
        type="number"
        value={input}
        onChange={handleInputChange}
        placeholder="Enter a number"
      />
      <div>
        <button onClick={() => calculate('add')}>Add</button>
        <button onClick={() => calculate('subtract')}>Subtract</button>
        <button onClick={() => calculate('multiply')}>Multiply</button>
        <button onClick={() => calculate('divide')}>Divide</button>
      </div>
      <div>
        <button onClick={resetInput}>Reset Input</button>
        <button onClick={resetResult}>Reset Result</button>
      </div>
    </div>
  );
}

export default SimpleCalculator;
